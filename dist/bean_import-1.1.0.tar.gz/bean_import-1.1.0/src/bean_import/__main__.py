if __name__ == "__main__":
    from bean_import.cli import app
    app()
