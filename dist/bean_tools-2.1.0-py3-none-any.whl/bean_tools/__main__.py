if __name__ == "__main__":
    from bean_tools.cli import app
    app()
