from . import __version__

def version():
    """
    Show version info and exit
    """

    print(f"v{__version__}")
